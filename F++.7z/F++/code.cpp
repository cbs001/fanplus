#include<iostream>
using namespace std;

int a[10005][10005];
int main(){
	freopen("in","r",stdin);
	freopen("out","w",stdout);
	cout<<"Hello,World!";
	return 0;
}